package Constructorproj;

public class Emp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

				
				Employee e1 = new Employee("Mitisha","Mitisha123@gmail.com");
				
				System.out.println(e1);
				
				e1.setName("Avani");
				e1.setEmail("Avani0103@gmail.com");
				
				System.out.println("name is: "+e1.getName());
				
				System.out.println("email is: "+e1.getEmail());
			}

		}
	


