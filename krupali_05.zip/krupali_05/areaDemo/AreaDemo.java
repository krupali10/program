package areaDemo;

public class AreaDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Area a = new Area();
		a.setDim(5,3);
		System.out.println("Area of rectangle is :"+a.getArea());

	}

}
