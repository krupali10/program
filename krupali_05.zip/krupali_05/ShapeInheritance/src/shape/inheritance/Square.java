package shape.inheritance;

public class Square extends Rectangle {

}
