package Interface_project;

public class Cat implements Animal{
	
	public String sound()
	{
		
		return "meow";
	}

}
