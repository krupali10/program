package Interface_project;

public interface Animal {
	
	public String sound();

}
