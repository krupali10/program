package Interface_project;

public class Dog implements Animal {
	
	public String sound()
	{
		
		return "Barking";
	}
}
