package finalExample;

public class FinalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FinalExample f1 = new FinalExample();
		f1.display();

	}

}
