package finalExample;

public class FinalExample {
	
    public int r=2;
	private final double pi = 3.14;
	
	public void display()
	{
		double circle = pi*r*r;
		System.out.println(circle);
	}
	
	/*public final void sayHello()
	{
		System.out.println("We learn Final");
	}*/

}
