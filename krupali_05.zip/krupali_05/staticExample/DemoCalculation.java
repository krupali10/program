package staticExample;

public class DemoCalculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculation c1 = new Calculation();
		System.out.println(c1);
		
		Calculation c2 = new Calculation();
		System.out.println(c2);
		
		Calculation c3 = new Calculation();
		System.out.println(c3);
		
		Calculation.display();
		
		//c1.count;
		
		
		System.out.println(Calculation.count);

	}

}
