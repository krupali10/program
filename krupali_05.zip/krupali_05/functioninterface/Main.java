package functioninterface;

public class Main {

	public void sayhello() {
		System.out.println("Avani Nakrani");
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Main m = new Main();
		m.sayhello();

	}

}
