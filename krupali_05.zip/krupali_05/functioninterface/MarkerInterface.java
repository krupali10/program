package functioninterface;

public interface MarkerInterface {

}
