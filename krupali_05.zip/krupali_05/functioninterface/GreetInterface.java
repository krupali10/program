package functioninterface;

public interface GreetInterface {
	
	public void sayhello();

}
