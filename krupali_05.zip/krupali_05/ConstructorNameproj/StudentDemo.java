package ConstructorNameproj;

public class StudentDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student s1 = new Student();
		System.out.println("Student name 1 :"+s1);
		
		Student s2 = new Student("Avani");
		System.out.println("Student name 2 :"+s2);
	}

}
