package DemoEmployee;

public class DemoEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1 = new Employee();
		e1.setEname("Avani");
		e1.setEmail("avani123@gmail.com");
		
		System.out.println(e1);
		

	}

}
