package wrapperExample;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AnimalSound an = new Cat();
		an.sound();
		AnimalSound an1 = new Dog();
		an1.sound();
	}

}
