package wrapperExample;

public class Cat implements AnimalSound{
	
	public void sound()
	{
		
		System.out.println("Meow");
	}

}
