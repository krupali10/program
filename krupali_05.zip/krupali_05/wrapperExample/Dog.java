package wrapperExample;

public class Dog implements AnimalSound{
	
	public void sound() {
		
	System.out.println("Barking");
	}

}
