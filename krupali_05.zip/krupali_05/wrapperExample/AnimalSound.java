package wrapperExample;

public interface AnimalSound {
	
   void sound();

}
