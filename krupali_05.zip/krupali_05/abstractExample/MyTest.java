package abstractExample;

public abstract class MyTest
{
	public void Calculation() {
		
	}
}
