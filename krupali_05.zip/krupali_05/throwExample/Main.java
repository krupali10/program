package throwExample;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		throwexample te = new throwexample();
		te.setMarks(-1);
		System.out.println(te.getMarks());

	}

}
